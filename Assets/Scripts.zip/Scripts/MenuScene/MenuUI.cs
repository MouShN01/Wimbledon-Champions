using System.Collections;
using System.Collections.Generic;
using kcp2k;
using Mirror;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

public class MenuUI : MonoBehaviour
{
    public TMP_InputField ipInputField;
    public TMP_InputField portInputField;
    public GameObject menu;
    public GameObject connMenu;

    private NetworkManager networkManager;

    void Start()
    {
        networkManager = FindObjectOfType<NetworkManagerWim>();
    }

    public void OnConnectButtonClicked()
    {
        // Получаем IP и порт из полей ввода
        string ipAddress = ipInputField.text;
        string portText = portInputField.text;

        if (int.TryParse(portText, out int port))
        {
            // Устанавливаем адрес и порт
            networkManager.networkAddress = ipAddress;
            networkManager.GetComponent<KcpTransport>().port = (ushort)port;

            // Пытаемся подключиться к хосту
            networkManager.StartClient();
        }
        else
        {
            Debug.LogError("Invalid port number");
        }
    }

    public void OnConnectMenuButtonClicked()
    {
        menu.SetActive(false);
        connMenu.SetActive(true);
    }

    public void OnBackButtonClick()
    {
        menu.SetActive(true);
        connMenu.SetActive(false);
    }

    public void Exit()
    {
#if UNITY_EDITOR
        EditorApplication.ExitPlaymode();
#endif
        Application.Quit();
    }
}
